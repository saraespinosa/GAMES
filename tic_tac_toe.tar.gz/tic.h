#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


#define USER 1
#define COMPUTER 2
#define NOWIN 0

struct point{
	int x;
	int y;
	char value;
};
struct point *matrix;	/* for our play panel */

void user_move(void);	/* get user to move */
void computer_move(void);	/* get computer to move */
int who_win(void);	/* who won the game */
void draw_matrix(void);
void matrix_init(void);
