#include "tic.h"

void draw_matrix(void)
{
	int i;

	printf("|---|---|---|\n");
	for(i = 0; i < 9; i++){
		printf("| %c ", (matrix + i)->value);
		if(i % 3 == 2)
			printf("|\n|---|---|---|\n");
	}
}
