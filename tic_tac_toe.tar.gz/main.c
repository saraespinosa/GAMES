/*
 * A tic-tac-toe game
 *
 * Author: Zhigang Song <1005411480a@gmail.com>
 *
 * Last modified: Mar. 28th, 2013
 *
 */

#include "tic.h"

int main()
{
	int whos_turn, who_won;

	printf("This is a simple game, you will play with the computer\n");
	printf("please select who for the first to play\n1. user[Enter 1]\n2. computer[Enter 2]\n");
	scanf("%d", &whos_turn);
	matrix_init();

	while(!(who_won = who_win())){
		draw_matrix();
		if(whos_turn == USER){
			printf("----------USER---------\n");
			user_move();
			whos_turn = COMPUTER;
		}else if(whos_turn == COMPUTER){
			printf("-------COMPUTER---------\n");
			computer_move();
			whos_turn = USER;
		}else{
			fprintf(stderr, "Error: Whos turn ? please try again!\n");
			exit(3);
		}
	}

	draw_matrix();
	if(who_won == USER)
		printf("You WIN\n");
	else
		printf("You LOSTTTTTT\n");

	printf("Thank for your playing, Bye!\n");

	return 0;
}

void matrix_init(void)
{
	int i, j;

	matrix = malloc(9 * sizeof(struct point));
	for(i = 1; i < 4; i++)
		for(j = 1; j < 4; j++){
			matrix->x = i;
			matrix->y = j;
			matrix->value = ' ';
			matrix++;
		}
	matrix -= 9;
}
