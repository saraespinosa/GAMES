#include "tic.h"

void user_move(void)
{
	int x, y;

	printf("please input the position you want like x, y\n");
	scanf("%d,%d", &x, &y);

	x--;
	y--;
	if((matrix + 3 * x + y)->value != ' '){
		printf("You can't play here!\n");
		user_move();
	}else{
		(matrix + 3 * x + y)->value = 'X';
	}
}

void computer_move(void)
{
	int i;
	for(i = 0; i < 9; i++)
		if((matrix + i)->value == ' '){
			(matrix + i)->value = 'O';
			break;
		}
}
