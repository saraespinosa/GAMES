#include "tic.h"

#define MVALUE(p) (matrix + p)->value
#define MPOSX(p) (matrix + p)->x
#define MPOSY(p) (matrix + p)->y


static int points_ok(int i, int j, int k)
{
	printf("------------------\n%d, %d, %d\n", i, j, k);
	int step1, step2, step3;

	step1 = MVALUE(i) == MVALUE(j) && MVALUE(j) == MVALUE(k);
	step2 = (MPOSY(i) != MPOSY(j)) && (MPOSY(j) != MPOSY(k)) && (MPOSY(i) != MPOSY(k));
	step3 = (MPOSX(i) != MPOSX(j)) && (MPOSX(j) != MPOSX(k)) && (MPOSX(i) != MPOSX(k));

	printf("step1: %dstep2: %dstep3: %d\n-------------------\n", step1, step2, step3);

	if(step1 && (step2 || step3))
		return 1;
	else
		return 0;
}

int who_win(void)
{
	int i, step, maxstep;

	for(i = 0; i < 3; i++){
		maxstep = (int)(9 - i) / 2 + 1;
		for(step = 1; step < maxstep; step++)
			if(points_ok(i, i + step, i + 2 * step)){
				if(MVALUE(i) == 'X'){
					printf("*****i is: %d*******\n", i);
					return USER;
				}else if(MVALUE(i) == 'O'){
					printf("*****i is: %d*******\n", i);
					return COMPUTER;
				}
			}
	}

	return NOWIN;
}
